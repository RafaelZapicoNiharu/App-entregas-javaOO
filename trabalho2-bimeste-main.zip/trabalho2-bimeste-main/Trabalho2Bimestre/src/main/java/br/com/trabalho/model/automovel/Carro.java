package br.com.trabalho.model.automovel;

import br.com.trabalho.model.diversos.Peso;

public class Carro extends Automovel{
    public Carro() {
    }

    public Carro(int renavan, String placa, Peso limitePeso) {
        super(renavan, placa, Peso.Mediano);
    }
}
