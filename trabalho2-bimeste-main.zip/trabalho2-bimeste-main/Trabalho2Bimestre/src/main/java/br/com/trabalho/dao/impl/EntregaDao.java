package br.com.trabalho.dao.impl;

import br.com.trabalho.connection.ConnectionFactory;
import br.com.trabalho.dao.DaoGenerics;
import br.com.trabalho.model.automovel.Automovel;
import br.com.trabalho.model.diversos.Entrega;
import br.com.trabalho.model.diversos.Peso;
import br.com.trabalho.model.diversos.Rota;
import br.com.trabalho.model.diversos.StatusEntrega;
import br.com.trabalho.model.usuario.Cliente;
import br.com.trabalho.model.usuario.Motorista;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class EntregaDao  implements DaoGenerics<Entrega, Integer> {

    @Override
    public void inserir(Entrega f) throws SQLException, ClassNotFoundException {
        Connection con = ConnectionFactory.getConnection();
        String sql = "INSERT INTO entrega " +
                " (`identrega`, " +
                " `preco`, " +
                " `dataentrega`, " +
                " `statusEntrega`, " +
                " `rota`, " +
                " `descricao`, " +
                " `localizacaoAtual`, " +
                " `renavan`, " +
                " `idcliente`)" +
                " VALUES (? , ?, ?, ?, ?, ?,' ', ?, ?); ";
        PreparedStatement prt = con.prepareStatement(sql);
        prt.setInt(1, f.getIdEntrega());
        prt.setDouble(2, f.getPreco());
        prt.setString(3, f.getDataEntrega().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        prt.setString(4, f.getStatusEntrega().toString()); //Enum - verificar como que deverá ficar
        prt.setString(5, f.getRota().toString()); //Enum - verificar como que deverá ficar
        prt.setString(6, f.getDescricao());

        prt.setInt(7, f.getVeiculo().getRenavan());
        prt.setInt(8, f.getCliente().getId());
        prt.executeUpdate();
    }
    public void alterar(Entrega f) throws SQLException, ClassNotFoundException {
        Connection con = ConnectionFactory.getConnection();
        String sql = " UPDATE entrega " +
                " SET" +
                " `identrega` = ?, " +
                " `preco` = ?, " +
                " `dataentrega` = ?, " +
                " `statusEntrega` = ?, " +
                " `rota` = ?, " +
                " `descricao` = ?, " +
                " `peso` = ?, " +
                " `localizacaoAtual` = ?, " +
                " `idmotorista` = ?, " +
                " `renavan` = ?, " +
                " `idcliente` = ? " +
                " WHERE `identrega` = ?; ";
        PreparedStatement prt = con.prepareStatement(sql);
        prt.setInt(1, f.getIdEntrega());
        prt.setDouble(2, f.getPreco());
        prt.setString(3, f.getDataEntrega().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        prt.setString(4, f.getStatusEntrega().toString()); //Enum - verificar como que deverá ficar
        prt.setString(5, f.getRota().toString()); //Enum - verificar como que deverá ficar
        prt.setString(6, f.getDescricao());
        prt.setString(7, f.getPeso().toString());
        prt.setString(8, f.getLocalizacaoAtual());
        prt.setInt(9,f.getMotorista().getId());
        prt.setInt(10, f.getVeiculo().getRenavan());
        prt.setInt(11, f.getCliente().getId());
        prt.setInt(12, f.getIdEntrega());
        prt.executeUpdate();
    }

    @Override
    public void apagar(Integer key) throws SQLException, ClassNotFoundException {
        Connection con = ConnectionFactory.getConnection();
        String sql = "DELETE FROM entrega WHERE identrega = ?";
        PreparedStatement prt = con.prepareStatement(sql);
        prt.setInt(1, key);
        prt.executeUpdate();
    }

    @Override
    public Entrega buscarUm(Integer key) throws SQLException, ClassNotFoundException {
        Connection con = ConnectionFactory.getConnection();
        String sql = "select *, m.*, c.* from entrega e " +
                "left join usuario as m on (e.idmotorista = m.id) " +
                "inner join usuario as c on (e.idcliente = c.id) " +
                "inner join automovel as a on (e.renavan = a.renavan)" +
                "where identrega = ? ;";
        PreparedStatement prt = con.prepareStatement(sql);
        prt.setInt(1, key);
        ResultSet rs = prt.executeQuery();
        Entrega e = null;
        if (rs.next()) {
            if (rs.getInt("idmotorista")==0){
                Automovel auto = new Automovel(rs.getInt("renavan"), rs.getString("a.placa"), Peso.valueOf(rs.getString("a.limitepeso")));
                Cliente cli = new Cliente(rs.getInt("idcliente"), rs.getString("c.login"), rs.getString("c.senha"),
                        rs.getString("c.nome"));
                e = new Entrega(rs.getInt("identrega"),rs.getDouble("preco"), LocalDate.parse(rs.getString("dataentrega")),
                        StatusEntrega.valueOf(rs.getString("statusEntrega")), Rota.valueOf(rs.getString("rota")), rs.getString("descricao"),
                        Peso.valueOf(rs.getString("peso")),
                        rs.getString("localizacaoAtual"),null, auto, cli);

            return e;
            }else{
                Motorista m = new Motorista(rs.getInt("idmotorista"), rs.getString("m.login"), rs.getString("m.senha"),
                        rs.getString("m.nome"));
                Automovel auto = new Automovel(rs.getInt("renavan"), rs.getString("a.placa"), Peso.valueOf(rs.getString("a.limitepeso")));
                Cliente cli = new Cliente(rs.getInt("idcliente"), rs.getString("c.login"), rs.getString("c.senha"),
                        rs.getString("c.nome"));
                e = new Entrega(rs.getInt("identrega"),rs.getDouble("preco"), LocalDate.parse(rs.getString("dataentrega")),
                        StatusEntrega.valueOf(rs.getString("statusEntrega")), Rota.valueOf(rs.getString("rota")), rs.getString("descricao"),
                        Peso.valueOf(rs.getString("peso")),
                        rs.getString("localizacaoAtual"),m, auto, cli);
                return e;
            }



        } else {
            return e;
        }
    }

    @Override
    public ArrayList<Entrega> buscarTodos() throws SQLException, ClassNotFoundException {
        Connection con = ConnectionFactory.getConnection();
        String sql = "select *, m.*, c.* from entrega e " +
                "left join usuario as m on (e.idmotorista = m.id) " +
                "inner join usuario as c on (e.idcliente = c.id) " +
                "inner join automovel as a on (e.renavan = a.renavan); ";
        PreparedStatement prt = con.prepareStatement(sql);
        ResultSet rs = prt.executeQuery();
        ArrayList<Entrega> entregas = new ArrayList<>();


        while (rs.next()) {
            if (rs.getInt("idmotorista")==0){
                Automovel auto = new Automovel(rs.getInt("renavan"), rs.getString("a.placa"), Peso.valueOf(rs.getString("a.limitepeso")));
                Cliente cli = new Cliente(rs.getInt("idcliente"), rs.getString("c.login"), rs.getString("c.senha"),
                        rs.getString("c.nome"));
                Entrega e = new Entrega(rs.getInt("identrega"),rs.getDouble("preco"), LocalDate.parse(rs.getString("dataentrega")),
                        StatusEntrega.valueOf(rs.getString("statusEntrega")), Rota.valueOf(rs.getString("rota")), rs.getString("descricao"),
                        Peso.valueOf(rs.getString("peso")),
                        rs.getString("localizacaoAtual"),null, auto, cli);
                entregas.add(e);
            }else{
                Motorista m = new Motorista(rs.getInt("idmotorista"), rs.getString("m.login"), rs.getString("m.senha"),
                        rs.getString("m.nome"));
                Automovel auto = new Automovel(rs.getInt("renavan"), rs.getString("a.placa"), Peso.valueOf(rs.getString("a.limitepeso")));
                Cliente cli = new Cliente(rs.getInt("idcliente"), rs.getString("c.login"), rs.getString("c.senha"),
                        rs.getString("c.nome"));
                Entrega e = new Entrega(rs.getInt("identrega"),rs.getDouble("preco"), LocalDate.parse(rs.getString("dataentrega")),
                        StatusEntrega.valueOf(rs.getString("statusEntrega")), Rota.valueOf(rs.getString("rota")), rs.getString("descricao"),
                        Peso.valueOf(rs.getString("peso")),
                        rs.getString("localizacaoAtual"),m, auto, cli);
                entregas.add(e);
            }


        }
        return entregas;
    }

    public ArrayList<Entrega> buscarTodosId(Integer key)throws SQLException, ClassNotFoundException {
        Connection con = ConnectionFactory.getConnection();
        String sql = "select *, m.*, c.* from entrega e " +
                "left join usuario as m on (e.idmotorista = m.id) " +
                "inner join usuario as c on (e.idcliente = c.id) " +
                "inner join automovel as a on (e.renavan = a.renavan) " +
                "where identrega = ? ; ";
        PreparedStatement prt = con.prepareStatement(sql);

        prt.setInt(1, key);
        ResultSet rs = prt.executeQuery();
        ArrayList<Entrega> entregas = new ArrayList<>();


        while (rs.next()) {
            if (rs.getInt("idmotorista")==0){
                Automovel auto = new Automovel(rs.getInt("renavan"), rs.getString("a.placa"), Peso.valueOf(rs.getString("a.limitepeso")));
                Cliente cli = new Cliente(rs.getInt("idcliente"), rs.getString("c.login"), rs.getString("c.senha"),
                        rs.getString("c.nome"));
                Entrega e = new Entrega(rs.getInt("identrega"),rs.getDouble("preco"), LocalDate.parse(rs.getString("dataentrega")),
                        StatusEntrega.valueOf(rs.getString("statusEntrega")), Rota.valueOf(rs.getString("rota")), rs.getString("descricao"),
                        Peso.valueOf(rs.getString("peso")),
                        rs.getString("localizacaoAtual"),null, auto, cli);
                entregas.add(e);
            }else{
                Motorista m = new Motorista(rs.getInt("idmotorista"), rs.getString("m.login"), rs.getString("m.senha"),
                        rs.getString("m.nome"));
                Automovel auto = new Automovel(rs.getInt("renavan"), rs.getString("a.placa"), Peso.valueOf(rs.getString("a.limitepeso")));
                Cliente cli = new Cliente(rs.getInt("idcliente"), rs.getString("c.login"), rs.getString("c.senha"),
                        rs.getString("c.nome"));
                Entrega e = new Entrega(rs.getInt("identrega"),rs.getDouble("preco"), LocalDate.parse(rs.getString("dataentrega")),
                        StatusEntrega.valueOf(rs.getString("statusEntrega")), Rota.valueOf(rs.getString("rota")), rs.getString("descricao"),
                        Peso.valueOf(rs.getString("peso")),
                        rs.getString("localizacaoAtual"),m, auto, cli);
                entregas.add(e);
            }


        }
        return entregas;
    }
/*    public alterar (Entrega f) throws SQLException, ClassNotFoundException{

    }*/

}
