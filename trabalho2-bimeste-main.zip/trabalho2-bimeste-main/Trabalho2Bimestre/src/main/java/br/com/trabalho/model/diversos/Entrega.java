package br.com.trabalho.model.diversos;

import br.com.trabalho.model.automovel.Automovel;
import br.com.trabalho.model.usuario.Cliente;
import br.com.trabalho.model.usuario.Motorista;
import br.com.trabalho.model.usuario.Usuario;

import javax.net.ssl.KeyManagerFactorySpi;
import java.time.LocalDate;
import java.util.ArrayList;

public class Entrega {
    private int idEntrega;
    private double preco;
    private LocalDate dataEntrega;

    private StatusEntrega statusEntrega;

    private Rota rota;
    private String descricao;
    private Peso peso;

    private String localizacaoAtual;

    private Motorista motorista;

    private Automovel veiculo;

    private Cliente cliente;

    public void calculaPreco(){
        double taxatipo = 0;
        int kms = 0;
        switch (this.peso){
            case Leve:
                taxatipo = 10.50;
                break;
            case Mediano:
                taxatipo = 17.75;
                break;
            case Pesado:
                taxatipo = 32.50;
                break;
        }
        switch (this.rota){
            case SP_BH:
                kms = 592;
                break;
            case SP_RJ:
                kms = 434;
                break;
            case RJ_BH:
                kms = 441;
                break;
        }
        this.preco = taxatipo * kms;
    }

    public Entrega() {
    }

    public Entrega(int idEntrega, double preco, LocalDate dataEntrega, StatusEntrega statusEntrega, Rota rota, String descricao, Peso peso, String localizacaoAtual, Motorista motorista, Automovel veiculo, Cliente cliente) {
        this.idEntrega = idEntrega;
        this.preco = preco;
        this.dataEntrega = dataEntrega;
        this.statusEntrega = statusEntrega;
        this.rota = rota;
        this.descricao = descricao;
        this.peso = peso;
        this.localizacaoAtual = localizacaoAtual;
        this.motorista = motorista;
        this.veiculo = veiculo;
        this.cliente = cliente;
        this.calculaPreco(); // Confirmar se no metodo construtor tem que ter o metodo de calculo
    }

    public int getIdEntrega() {
        return idEntrega;
    }

    public void setIdEntrega(int idEntrega) {
        this.idEntrega = idEntrega;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public LocalDate getDataEntrega() {
        return dataEntrega;
    }

    public void setDataEntrega(LocalDate dataEntrega) {
        this.dataEntrega = dataEntrega;
    }

    public StatusEntrega getStatusEntrega() {
        return statusEntrega;
    }

    public void setStatusEntrega(StatusEntrega statusEntrega) {
        this.statusEntrega = statusEntrega;
    }

    public Rota getRota() {
        return rota;
    }

    public void setRota(Rota rota) {
        this.rota = rota;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Peso getPeso() {
        return peso;
    }

    public void setPeso(Peso peso) {
        this.peso = peso;
    }

    public String getLocalizacaoAtual() {
        return localizacaoAtual;
    }

    public void setLocalizacaoAtual(String localizacaoAtual) {
        this.localizacaoAtual = localizacaoAtual;
    }

    public Motorista getMotorista() {
        return motorista;
    }

    public void setMotorista(Motorista motorista) {
        this.motorista = motorista;
    }

    public Automovel getVeiculo() {
        return veiculo;
    }

    public void setVeiculo(Automovel veiculo) {
        this.veiculo = veiculo;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
}
