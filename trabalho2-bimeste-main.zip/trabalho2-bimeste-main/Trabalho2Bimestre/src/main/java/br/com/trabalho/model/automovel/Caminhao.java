package br.com.trabalho.model.automovel;

import br.com.trabalho.model.diversos.Peso;

public class Caminhao extends Automovel {
    public Caminhao() {
    }

    public Caminhao(int renavan, String placa, Peso limitePeso) {
        super(renavan, placa, Peso.Pesado);
    }
}
