package br.com.trabalho.model.automovel;

import br.com.trabalho.model.diversos.Peso;

public class Automovel {
    private int renavan; //composto de 11 digitos
    private String placa;

    private Peso limitePeso;

    public Automovel() {
    }

    public Automovel(int renavan, String placa, Peso limitePeso) {
        this.renavan = renavan;
        this.placa = placa;
        this.limitePeso = limitePeso;
    }

    public Peso getLimitePeso() {
        return limitePeso;
    }

    public void setLimitePeso(Peso limitePeso) {
        this.limitePeso = limitePeso;
    }

    public int getRenavan() {
        return renavan;
    }

    public void setRenavan(int renavan) {
        this.renavan = renavan;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }
}
