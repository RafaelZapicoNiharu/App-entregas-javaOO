package br.com.trabalho.model.diversos;

public enum Rota {

    SP_RJ, SP_BH, RJ_BH;
}
