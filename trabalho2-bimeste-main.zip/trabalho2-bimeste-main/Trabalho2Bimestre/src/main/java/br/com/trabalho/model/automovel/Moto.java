package br.com.trabalho.model.automovel;

import br.com.trabalho.model.diversos.Peso;

public class Moto extends Automovel{
    public Moto() {
    }

    public Moto(int renavan, String placa, Peso limitePeso) {
        super(renavan, placa, Peso.Leve);
    }
}
