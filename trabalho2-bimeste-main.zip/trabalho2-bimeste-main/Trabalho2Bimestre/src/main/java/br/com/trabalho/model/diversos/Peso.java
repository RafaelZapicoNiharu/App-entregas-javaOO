package br.com.trabalho.model.diversos;

public enum Peso {
    Leve, Mediano, Pesado;
}
