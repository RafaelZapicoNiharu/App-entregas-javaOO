package br.com.trabalho.model.usuario;

import br.com.trabalho.model.diversos.Entrega;

import java.util.ArrayList;

public class Cliente extends Usuario{
    public Cliente() {
    }

    public Cliente(int id, String login, String senha, String nome) {
        super(id, login, senha, nome, "cliente");
    }

    public Cliente(int id, String login, String senha, String nome, String tipousuario) {
        super(id, login, senha, nome, tipousuario);
    }
}
