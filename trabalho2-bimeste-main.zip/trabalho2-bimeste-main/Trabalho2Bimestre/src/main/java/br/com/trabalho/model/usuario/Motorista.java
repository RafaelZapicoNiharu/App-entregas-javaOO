package br.com.trabalho.model.usuario;

import br.com.trabalho.model.diversos.Entrega;

import java.util.ArrayList;

public class Motorista extends Usuario {


    public Motorista() {
    }


    public Motorista(int id, String login, String senha, String nome) {
        super(id, login, senha, nome, "motorista");

}
    public Motorista(int id, String login, String senha, String nome, String tipousuario) {
        super(id, login, senha, nome, tipousuario);
    }
}

