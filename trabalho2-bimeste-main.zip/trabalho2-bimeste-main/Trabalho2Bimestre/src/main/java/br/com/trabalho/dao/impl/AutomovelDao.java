package br.com.trabalho.dao.impl;

import br.com.trabalho.connection.ConnectionFactory;
import br.com.trabalho.dao.DaoGenerics;
import br.com.trabalho.model.automovel.Automovel;
import br.com.trabalho.model.diversos.Peso;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

public class AutomovelDao implements DaoGenerics<Automovel, Integer>{

    @Override
    public void inserir(Automovel f) throws SQLException, ClassNotFoundException {
        Connection con = ConnectionFactory.getConnection();
        String sql = "INSERT INTO automovel " +
                " (`renavan`, " +
                " `placa`, " +
                " `limitepeso`) " +
                " VALUES (? , ? , ?); ";
        PreparedStatement prt = con.prepareStatement(sql);

        prt.setInt(1, f.getRenavan());
        prt.setString(2, f.getPlaca());
        prt.setString(3, f.getLimitePeso().toString()); //Enum - verificar como que deverá ficar
        prt.executeUpdate();

    }

    @Override
    public void apagar(Integer key) throws SQLException, ClassNotFoundException {
        Connection con = ConnectionFactory.getConnection();
        String sql = "DELETE FROM automovel WHERE renavan = ?";
        PreparedStatement prt = con.prepareStatement(sql);
        prt.setInt(1, key);
        prt.executeUpdate();
    }

    @Override
    public Automovel buscarUm(Integer key) throws SQLException, ClassNotFoundException {
        Connection con = ConnectionFactory.getConnection();
        String sql = "SELECT * FROM automovel WHERE renavan = ?; ";
        PreparedStatement prt = con.prepareStatement(sql);
        prt.setInt(1, key);
        ResultSet rs = prt.executeQuery();
        Automovel auto = null;
        if (rs.next()) {
            auto = new Automovel(rs.getInt("renavan"), rs.getString("placa"), Peso.valueOf(rs.getString("limitepeso")));
            return auto;
        } else {
            return auto;
        }
    }

    @Override
    public ArrayList<Automovel> buscarTodos() throws SQLException, ClassNotFoundException {
        Connection con = ConnectionFactory.getConnection();
        String sql = "SELECT * FROM automovel;";
        PreparedStatement prt = con.prepareStatement(sql);
        ResultSet rs = prt.executeQuery();
        ArrayList<Automovel> automoveis = new ArrayList<>();
        while (rs.next()) {
            Automovel auto = new Automovel(rs.getInt("renavan"), rs.getString("placa"), Peso.valueOf(rs.getString("limitepeso")));
            automoveis.add(auto);
        }
        return automoveis;
    }

    public Object buscarUmPlaca(String placa) throws SQLException, ClassNotFoundException {
        Connection con = ConnectionFactory.getConnection();
        String sql = "SELECT * FROM automovel WHERE placa = ?; ";
        PreparedStatement prt = con.prepareStatement(sql);
        prt.setString(1, placa);
        ResultSet rs = prt.executeQuery();
        Automovel auto = null;
        if (rs.next()) {
            auto = new Automovel(rs.getInt("renavan"), rs.getString("placa"), Peso.valueOf(rs.getString("limitepeso")));
            return auto;
        } else {
            return auto;
        }
    }
}
