package br.com.trabalho.dao;

import java.sql.SQLException;
import java.util.ArrayList;

public interface DaoGenerics<C,K>{
    public void inserir(C f) throws SQLException, ClassNotFoundException;
    public void apagar(K key) throws SQLException, ClassNotFoundException;
    public C buscarUm(K key) throws SQLException, ClassNotFoundException;
    public ArrayList<C> buscarTodos() throws SQLException, ClassNotFoundException;

}