package br.com.trabalho;

import br.com.trabalho.dao.impl.EntregaDao;
import br.com.trabalho.model.diversos.Entrega;

import java.sql.SQLException;
import java.util.ArrayList;

public class Main {


    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        Entrega teste = new EntregaDao().buscarUm(1);
        System.out.println(teste.getMotorista().getId());
    }
}