package br.com.trabalho.model.diversos;

public enum StatusEntrega {
    Aberto, ACaminho, Entregue;
}
