package br.com.trabalho.dao.impl;

import br.com.trabalho.connection.ConnectionFactory;
import br.com.trabalho.dao.DaoGenerics;
import br.com.trabalho.model.automovel.Automovel;
import br.com.trabalho.model.usuario.Administrador;
import br.com.trabalho.model.usuario.Cliente;
import br.com.trabalho.model.usuario.Motorista;
import br.com.trabalho.model.usuario.Usuario;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Objects;

public class UsuarioDao implements DaoGenerics<Usuario, Integer> {
    @Override
    public void inserir(Usuario f) throws SQLException, ClassNotFoundException {
        Connection con = ConnectionFactory.getConnection();
        String sql = "INSERT INTO `transportadora`.`usuario` " +
                "(`id`, " +
                "`login`, " +
                "`senha`, " +
                "`nome`, " +
                "`tipoUsuario`) " +
                "VALUES " +
                "(?, " +
                "?, " +
                "?, " +
                "?, " +
                "?); ";
        PreparedStatement prt = con.prepareStatement(sql);
        prt.setInt(1, f.getId());
        prt.setString(2, f.getLogin());
        prt.setString(3, f.getSenha());
        prt.setString(4, f.getNome());
        prt.setString(5, f.getTipoUsuario());

        prt.executeUpdate();
    }


    @Override
    public void apagar(Integer key) throws SQLException, ClassNotFoundException {Connection con = ConnectionFactory.getConnection();
        String sql = "DELETE FROM usuario WHERE id = ?";
        PreparedStatement prt = con.prepareStatement(sql);
        prt.setInt(1, key);
        prt.executeUpdate();
    }

    @Override
    public Usuario buscarUm(Integer key) throws SQLException, ClassNotFoundException {
        Connection con = ConnectionFactory.getConnection();
        String sql = "SELECT `id`, " +
                " `login`, " +
                " `senha`, " +
                " `nome`, " +
                " `tipoUsuario` " +
                "FROM `usuario` " +
                "WHERE id = ?; ";
        PreparedStatement prt = con.prepareStatement(sql);
        prt.setInt(1, key);
        ResultSet rs = prt.executeQuery();
        Usuario user = null;
        if (rs.next()) {
            if(Objects.equals(rs.getString("tipoUsuario"), "motorista")){
                user = new Motorista(rs.getInt("id"), rs.getString("login"), rs.getString("senha"),
                        rs.getString("nome"), rs.getString("tipoUsuario"));
            }else if((Objects.equals(rs.getString("tipoUsuario"), "cliente"))){
                user = new Cliente(rs.getInt("id"), rs.getString("login"), rs.getString("senha"),
                        rs.getString("nome"), rs.getString("tipoUsuario"));
            }else if ((Objects.equals(rs.getString("tipoUsuario"), "administrador"))){
                user = new Administrador(rs.getInt("id"), rs.getString("login"), rs.getString("senha"),
                        rs.getString("nome"), rs.getString("tipoUsuario"));
            }

            return user;
        } else {
            return user;
        }
    }

    public Usuario buscarPorLogin(String login, String senha) throws SQLException, ClassNotFoundException {
        Connection con = ConnectionFactory.getConnection();
        String sql = "SELECT `id`, " +
                " `login`, " +
                " `senha`, " +
                " `nome`, " +
                " `tipoUsuario` " +
                "FROM `usuario` " +
                "WHERE login = ? AND senha = ? ; ";
        PreparedStatement prt = con.prepareStatement(sql);
        prt.setString(1, login);
        prt.setString(2, senha);
        ResultSet rs = prt.executeQuery();
        Usuario user = null;
        if (rs.next()) {
            user = new Usuario(rs.getInt("id"), rs.getString("login"), rs.getString("senha"),
                    rs.getString("nome"), rs.getString("tipoUsuario"));
            return user;
        } else {
            return user;
        }
    }

    @Override
    public ArrayList<Usuario> buscarTodos() throws SQLException, ClassNotFoundException {
        Connection con = ConnectionFactory.getConnection();
        String sql = "SELECT * FROM usuario;";
        PreparedStatement prt = con.prepareStatement(sql);
        ResultSet rs = prt.executeQuery();
        ArrayList<Usuario> users = new ArrayList<>();
        while (rs.next()) {
            Usuario user = new Usuario(rs.getInt("id"), rs.getString("login"), rs.getString("senha"),
                    rs.getString("nome"),rs.getString("tipoUsuario"));
            users.add(user);
        }
        return users;
    }

    public Object buscarUmNome(String Nome) throws SQLException, ClassNotFoundException {
        Connection con = ConnectionFactory.getConnection();
        String sql = "SELECT `id`, " +
                " `login`, " +
                " `senha`, " +
                " `nome`, " +
                " `tipoUsuario` " +
                "FROM `usuario` " +
                "WHERE nome = ?; ";
        PreparedStatement prt = con.prepareStatement(sql);
        prt.setString(1, Nome);
        ResultSet rs = prt.executeQuery();
        Usuario user = null;
        if (rs.next()) {
            if(Objects.equals(rs.getString("tipoUsuario"), "motorista")){
                user = new Motorista(rs.getInt("id"), rs.getString("login"), rs.getString("senha"),
                        rs.getString("nome"), rs.getString("tipoUsuario"));
            }else if((Objects.equals(rs.getString("tipoUsuario"), "cliente"))){
                user = new Cliente(rs.getInt("id"), rs.getString("login"), rs.getString("senha"),
                        rs.getString("nome"), rs.getString("tipoUsuario"));
            }else if ((Objects.equals(rs.getString("tipoUsuario"), "administrador"))){
                user = new Administrador(rs.getInt("id"), rs.getString("login"), rs.getString("senha"),
                        rs.getString("nome"), rs.getString("tipoUsuario"));
            }

            return user;
        } else {
            return user;
        }
    }
}
